package com.example.Deber01VideojuegoPersonaje

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Deber01VideojuegoPersonajeApplication

fun main(args: Array<String>) {
	runApplication<Deber01VideojuegoPersonajeApplication>(*args)
}

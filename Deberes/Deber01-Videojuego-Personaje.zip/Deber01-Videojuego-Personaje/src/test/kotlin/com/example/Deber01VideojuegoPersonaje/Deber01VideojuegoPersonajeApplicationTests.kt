package com.example.Deber01VideojuegoPersonaje

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Deber01VideojuegoPersonajeApplicationTests {

	@Test
	fun contextLoads() {
	}

}

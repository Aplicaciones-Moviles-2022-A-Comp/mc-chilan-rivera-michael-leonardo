package com.example.Deber01CRUDJuegoPersonajeDeJuego

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Deber01CrudJuegoPersonajeDeJuegoApplicationTests {

	@Test
	fun contextLoads() {
	}

}

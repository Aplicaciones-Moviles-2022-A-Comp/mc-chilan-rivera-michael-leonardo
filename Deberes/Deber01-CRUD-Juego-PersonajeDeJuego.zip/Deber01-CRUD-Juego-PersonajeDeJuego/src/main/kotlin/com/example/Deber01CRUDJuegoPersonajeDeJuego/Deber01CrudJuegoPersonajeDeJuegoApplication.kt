package com.example.Deber01CRUDJuegoPersonajeDeJuego

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Deber01CrudJuegoPersonajeDeJuegoApplication

fun main(args: Array<String>) {
	runApplication<Deber01CrudJuegoPersonajeDeJuegoApplication>(*args)
}
